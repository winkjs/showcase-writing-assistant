1. Incorrect contractions — cant v/s can't ----> but cant is also a word --->>> contraction flat - true
2. Incorrect punctuation spacing — yes, v/s yes ,

3. First word of sentence is not capitalized ---

4. Use of adverbs should be discouraged - light color
5. Use of passive voice — [am/are/were/being/is/been/was/be] followed by a past tense verb
6. Long sentence >15 words; very long sentence >21 words — refer to for further refinement https://techcomm.nz/Story?Action=View&Story_id=106
7. Duplicate words — the the OR the <newline> the; <newline> will be "\n" in javascript
   *8. Do not use abusive words
   *9. Consistent spelling — either british or american
8. Consistent apostrophe ' vs ’
   \*11. Avoid constructs: am in the morning, pm in the adternoon/evening/night, 12 noon
9. The word "yes" should always follow a "," or "."
10. Wordiness — refer to https://www.thoughtco.com/common-redundancies-in-english-1692776 It includes redundant acronym syndrome (RAS) — ATM machine, ABS brakes, HIV virus, PIN number, LCD display, UPC code, please RSVP etc. Refer to http://www.nanday.com/rap/
11. Highlight use of oxymorons — refer to http://www.fun-with-words.com/oxym_example.html
12. Avoid starting sentence with words "So","Just","There".
